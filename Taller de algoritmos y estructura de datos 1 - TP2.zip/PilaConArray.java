
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 07/11/2022


import java.util.Scanner;

public class PilaConArray {
	

		private int[] Pila = new int [10];
		private int tamaño = 0;
		
		
	//apilar
		
	public void apilar(int valor) {
		if (tamaño == Pila.length) {
			System.out.println("La pila esta llena.\n");
			}
		else {
			Pila[tamaño] = valor;
			tamaño++;
		}
	}
		
	//desapilar
	
	public int desapilar() {
		if (tamaño == 0) {
			System.out.println("La pila esta vacia\n");
			return 0;
		}
		else {
			int result = Pila[tamaño-1];
			Pila[tamaño-1] = 0; //Setea el valor del tope en 0.
			tamaño--;
			return result;
		}
	}
	
	//isEmpty
	
	public boolean estaVacia() {
		boolean vacia;
		if (tamaño == 0) {
			vacia = true;
		}
		else {
			vacia = false;
		}
		return vacia;
	}	
		



public static void main (String[] args) {
	
	PilaConArray pila = new PilaConArray();
	Scanner teclado = new Scanner(System.in);
	
	//Loop para no cortar el programa
    int loop = 0;
    while (loop == 0) {
	
	System.out.println("\nIngrese una opcion: \n");
	System.out.println("1. Apilar un valor.");
	System.out.println("2. Desapilar el tope de la pila.");
	System.out.println("3. Consultar si la pila esta vacia. \n");
	
	int opcion = teclado.nextInt();
	
	switch(opcion) {
	
	case 1:
		Scanner teclado2 = new Scanner(System.in);
		System.out.print("Ingrese un valor entero: "); 
		
		int valorEntero = teclado2.nextInt();
		
		pila.apilar(valorEntero);
		
		
		break;
	
	case 2:
		int valorDesapilado = pila.desapilar();
		if (valorDesapilado != 0) {
		System.out.println("Se ha desapilado el numero " + valorDesapilado + " del tope de la pila.\n");
		}
		break;
		
	case 3:
		boolean vacia = pila.estaVacia();
		if (vacia == true) {
			System.out.println("La pila esta vacia.\n");
		}
		else {
			System.out.println("La pila NO esta vacia.\n");
		}
		break;
	
	default:
    	System.out.print("No ingreso ninguna opcion correcta. \n ");	
		
	}
	
}	}

}
