
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 07/11/2022

public class Nodo {
	int valor;
	Nodo siguiente;

}
