
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 07/11/2022

import java.util.Scanner;

public class FabricaDeLadrillos {
	
	public static void main (String[] args) {
		ColaConListaEnlazada cola = new ColaConListaEnlazada();
		Scanner teclado = new Scanner(System.in);
		
		pedido[] ListaDePedidos = new pedido[10];
		
		int codigo = 0; //lo iniciamos en 0 para ir incrementandolo por cada pedido.
		
		//Loop para no cortar el programa
	    int loop = 0;
	    while (loop == 0) {
		
		System.out.println("\nIngrese una opcion: \n");
		System.out.println("1. Ingrese un nuevo pedido.");
		System.out.println("2. Mostrar pedidos encolados.\n");
		
		int opcion = teclado.nextInt();
		
		switch(opcion) {
		
		case 1:
			pedido nuevoPedido = new pedido();
			nuevoPedido.codigo = codigo++;
			Scanner teclado2 = new Scanner(System.in);
			
			System.out.print("Ingrese el nombre del cliente: ");
			nuevoPedido.cliente = teclado2.nextLine();
			
			System.out.print("Ingrese la cantidad de ladrillos: ");
			nuevoPedido.cantidad = teclado2.nextInt();
			
			for (int i=0 ; i<ListaDePedidos.length ; i++){
				if(ListaDePedidos[i] == null) {
					ListaDePedidos[i] = nuevoPedido;
					break;
				}
			}
			
			break;
		
		case 2:
			for (int i=0 ; i<ListaDePedidos.length ; i++) {
				if (ListaDePedidos[i] != null) {
					ListaDePedidos[i].getPedido();
				}
			}
		
		default:
	    	System.out.print("No ingreso ninguna opcion correcta. \n ");
			
		}
		
	}

}}
