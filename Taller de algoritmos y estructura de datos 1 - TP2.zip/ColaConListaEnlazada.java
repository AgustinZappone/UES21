
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 07/11/2022

import java.util.Scanner;

public class ColaConListaEnlazada {
	private Nodo inicioCola, finalCola;
	String cola = "";
	
	public ColaConListaEnlazada() {
		inicioCola = null;
		finalCola = null;	
	}
	
	public boolean colaVacia() {
		if (inicioCola == null) {
			return true;
		}
		else {
			return false;
		}
	}

	public void encolar(int valor) {
		Nodo nuevoNodo = new Nodo();
		nuevoNodo.valor = valor;
		nuevoNodo.siguiente = null;
		
		if (colaVacia()) {
			inicioCola = nuevoNodo;
			finalCola = nuevoNodo;
		}
		else {
			finalCola.siguiente = nuevoNodo;
			finalCola = nuevoNodo;
		}
	}

	public int desencolar() {
		if (!colaVacia()) {
			int valorDesencolado = inicioCola.valor;
			
			if(inicioCola == finalCola) {
				inicioCola = null;
				finalCola = null;
			}
			else {
				inicioCola = inicioCola.siguiente;
			}
			return valorDesencolado;
		}
		return 0;
	}
	


public static void main (String[] args) {
	ColaConListaEnlazada cola = new ColaConListaEnlazada();
	Scanner teclado = new Scanner(System.in);
	
	//Loop para no cortar el programa
    int loop = 0;
    while (loop == 0) {
	
	System.out.println("\nIngrese una opcion: \n");
	System.out.println("1. Encolar un valor.");
	System.out.println("2. Desencolar el tope de la pila.");
	System.out.println("3. Consultar si la cola esta vacia. \n");
	
	int opcion = teclado.nextInt();
	
	switch(opcion) {
	
	case 1:
		Scanner teclado2 = new Scanner(System.in);
		System.out.print("Ingrese un valor entero: "); 
		
		int valorEntero = teclado2.nextInt();
		
		cola.encolar(valorEntero);
		
		
		break;
	
	case 2:
		int valorDesencolado = cola.desencolar();
		if (valorDesencolado != 0) {
		System.out.println("Se ha desencolado el numero " + valorDesencolado + ".\n");
		}
		else {
			System.out.println("La cola esta vacia.\n");
		}
		break;
		
	case 3:
		boolean vacia = cola.colaVacia();
		if (vacia == true) {
			System.out.println("La cola esta vacia.\n");
		}
		else {
			System.out.println("La cola NO esta vacia.\n");
		}
		break;
	
	default:
    	System.out.print("No ingreso ninguna opcion correcta. \n ");	
		
	}
	
    }
}
}
