   
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 31/10/2022

import java.util.Scanner; 


public class Consigna2 { 
	
    public static void main(String[] args) { 
   
    int[] conteos = new int[26]; 

    Scanner teclado = new Scanner(System.in); 
   
    
    //Leer palabra del usuario

    System.out.print("Ingrese una palabra (por favor, solo letras): "); 

    String palabra = teclado.nextLine(); 
    
    
    //Convierte a mayusc. 

    palabra = palabra.toUpperCase(); 
    
    
    //Cuenta la frecuencia de cada letra...

    for (int i=0; i < palabra.length(); i++) {
    	try {
    		conteos[palabra.charAt(i)-'A']++;
    	}
    	
    	//Tal como fue pedido en la consigna 2 del TP, el siguiente catch detecta el 
    	//ArrayIndexOutOfBoundsException y muestra un mensaje con el caracter erroneo
    	catch (ArrayIndexOutOfBoundsException e) { 
    		
    		String caracterErroneo = null;
    		String caracter;
    		
    		for (int j=0; j < palabra.length(); j++) {
    			   			
    			caracter = String.valueOf(palabra.charAt(j));
    			//Regex para identificar caracteres no alfabeticos.
    			if (!caracter.matches(".*[A-Z].*")) {
    			
    				caracterErroneo = caracter;
    				break;
    			}
    		}
    		
    	System.out.println("\nEl caracter '" + caracterErroneo + "' no es una letra \n" + "Error: " + e);
    	
    	//Para evitar que el programa continue con el siguiente ciclo for,
    	//salimos del programa con un System.exit(1);
    	System.out.println("\n\nSaliendo del programa...");
    	System.exit(1);
    	}
    }
         

    //imprimir frecuencias...

    System.out.println(); 

    for (int i=0; i < conteos.length; i++) { 

        if (conteos [i] != 0) 

        System.out.println((char)(i +'A') + ": " + conteos[i]); 
    	}
    
    teclado.close();
    
     } 
    
}