
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 31/10/2022

import java.util.Scanner;

public class Consigna3Main {
	
    public static void main (String[] args) { 
   
    Scanner teclado = new Scanner(System.in); 
    Consigna3Class nuevo = new Consigna3Class();
    
    //Loop para no cortar el programa
    int loop = 0;
    while (loop == 0) {
    
    System.out.println("\nSeleccione una opcion:");
    System.out.println("1. Ingrese una nueva palabra.");
    System.out.println("2. Mostrar palabras guardadas");
    System.out.println("3. Elegir una palabra almacenada");
    System.out.println("4. Salir del programa \n");
    
    int opcion = teclado.nextInt();
    
    
    
    switch (opcion){
    
    case 1:
    	Scanner teclado2 = new Scanner(System.in);  
    	System.out.print("Ingrese una palabra (por favor, solo letras): "); 
    	
        String palabra = teclado2.nextLine(); 
        palabra = palabra.toUpperCase(); 
        nuevo.almacenarPalabra(palabra);
        break;
    case 2:
    	nuevo.getPalabrasAlmacenadas();
    	break;
    case 3:
    	Scanner teclado3 = new Scanner(System.in);
    	System.out.print("Ingrese el numero de alguna palabra almacenada: ");
    	int posicion = teclado3.nextInt();
    	palabra = nuevo.getPalabraAlmacenadaEnPosicion(posicion);
    	
    	nuevo.conteoDeLetras(palabra);
    	break;
    case 4:
    	System.out.print("Saliedo del programa...");
    	loop++;
    	System.exit(1);
    	
    default:
    	System.out.print("No ingreso ninguna opcion correcta. \n ");
    	
    }
    }
    

    teclado.close();
    
     } 
    
}

