
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 31/10/2022

public class Consigna3Class { 
	
	String palabra;
	String[] AlmacenDePalabras = new String[30];
	
	void almacenarPalabra(String palabraAlmacenar){
				
		for (int i=0 ; i < AlmacenDePalabras.length ; i++) {
			
			if (AlmacenDePalabras[i] == null) {
				AlmacenDePalabras[i] = palabraAlmacenar;
				break;
			}
		}
	}
	
	String getPalabraAlmacenadaEnPosicion(int posicion) {
		String Mostrar;
		Mostrar = AlmacenDePalabras[posicion];
		
		return Mostrar;
	}
	
	void getPalabrasAlmacenadas(){
		
		System.out.println("Las palabras almacenadas son: \n");
		
		for (int i=0; i < AlmacenDePalabras.length ; i++) {
			if (AlmacenDePalabras[i] != null) {
			System.out.println(i + ". " + AlmacenDePalabras[i]);
			}
		}
	}
	
	void setPalabra(String dato) {
		this.palabra = dato;
	}
	
	void conteoDeLetras(String palabra){
	    int[] conteos = new int[26]; 
		for (int i=0; i < palabra.length(); i++) {
	    	try {
	    		conteos[palabra.charAt(i)-'A']++;
	    	}
	    	
	    	catch (ArrayIndexOutOfBoundsException e) { 
	    		
	    		String caracterErroneo = null;
	    		String caracter;
	    		
	    		for (int j=0; j < palabra.length(); j++) {
	    			   			
	    			caracter = String.valueOf(palabra.charAt(j));
	    			//Regex para identificar caracteres no alfabeticos.
	    			if (!caracter.matches(".*[A-Z].*")) {
	    			
	    				caracterErroneo = caracter;
	    				break;
	    			}
	    		}
	    		
	    	System.out.println("\nEl caracter '" + caracterErroneo + "' no es una letra \n" + "Error: " + e);
	    	
	    	}
	    }
		System.out.println();
		for (int i=0; i < conteos.length; i++) { 
	        if (conteos [i] != 0) 
	        System.out.println((char)(i +'A') + ": " + conteos[i]); 
	    	}	    	    
	}
}
