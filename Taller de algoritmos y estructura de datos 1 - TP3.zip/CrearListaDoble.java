   
	//Nombre: Agustin Zappone
    //Legajo: VINF012766
    //DNI: 38327363
	//Fecha: 21/11/2022

import java.util.Scanner; 

public class CrearListaDoble {    
  
    //Creamos un nodo  
    class Nodo{    
        int dato;    
        Nodo anterior;    
        Nodo siguiente;    
  
        public Nodo(int dato) {    
            this.dato = dato;    
        }    
    }    
  
    //Inicializamos cola y cabeza    
    Nodo head = null;  
    Nodo tail = null;    
  
    //Metodo para añadir un nuevo nodo   
    public void añadirNuevoNodo(int dato) {    
      
        Nodo nuevoNodo = new Nodo(dato);    
   
        if(head == null) {  
               
            head = nuevoNodo;  
            tail = nuevoNodo;  
                
            head.anterior = null;    
            tail.siguiente = null;    
        }  
          
        else {    
  
            //The newly created node will be the last node, so now tail's next will point to that newly created node  
            tail.siguiente = nuevoNodo;    
            //The tail is pointing to the second last node so the newly created node's prev will point to tail    
            nuevoNodo.anterior = tail;    
            //The newly created node will become new tail because it is last node in the doubly linked list   
            tail = nuevoNodo;    
            //The newly created node will be the last node so tail's next will be null    
            tail.siguiente = null;    
        }    
    }    
  
    //Creamos metodo para mostrar los datos de la lista   
    public void mostrarDatos() {  
            
        Nodo actual = head;    
         
        if(head == null) {  
              
            System.out.println("La lista esta vacia");    
            return;    
        }  
         
        System.out.println("Nodos de la lista doble enlazada: ");    
         
        while(actual != null) {    
                
            System.out.print(actual.dato + "\n");    
            actual = actual.siguiente;    
        }    
    }
    
    //Creamos metodo para ordenar la lista.
    public void ordenarLista() {  
        Nodo actual = null, indice = null;  
        int temp;  
        //Chequeamos si la lista esta vacia  
        if(head == null) {  
            return;  
        }  
        else {  
             
            for(actual = head; actual.siguiente != null; actual = actual.siguiente) {  
                  
                for(indice = actual.siguiente; indice != null; indice = indice.siguiente) {  
                      
                    if(actual.dato > indice.dato) {  
                        temp = actual.dato;  
                        actual.dato = indice.dato;  
                        indice.dato = temp;  
                    }  
                }  
            }  
        }  
    } 
  
    public static void main(String[] args) {    
    	
    	Scanner teclado = new Scanner(System.in);
    	
    	CrearListaDoble obj = new CrearListaDoble();
    	int aux = 0;
    	
    	while(aux == 0) {	//Creamos un loop infinito para que siga pidiendo el ingreso de datos
    	
    	System.out.println("Elija una opcion:");
    	System.out.println("1.Añadir un nuevo numero a la lista");
    	System.out.println("2. Mostrar lista");
    	
    	int opcion = teclado.nextInt();
    	
    	switch(opcion) {
    	case 1:
    		System.out.print("Ingrese numero para añadir a la lista enlazada doble: ");
        	int numero = teclado.nextInt();
      
                	
            obj.añadirNuevoNodo(numero);
            System.out.print("\n");
            break;
        
    	case 2:
    		//Ordenamos los datos de la lista y despues mostramos la lista ya ordenada.   
    		System.out.print("\n");
    		obj.ordenarLista();
    		obj.mostrarDatos();
    		System.out.print("\n");
    		break;
    	}
    	}
    	
    }     
  
            
}    
  